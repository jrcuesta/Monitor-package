monitor_edaplot<-
  function (df, sortref = TRUE, nc = FALSE, p = FALSE, alpha = 0.05,
            sec = FALSE, sd = FALSE)
  {
    if (ncol(df) > 3) {
      stop("Dataframe columns must be four: Sample ID, Ref Value and Pred Value")
    }
    if (alpha > 0.1 | alpha == FALSE) {
      stop("the alpha value must be between 0,1 and 0.001\n           - Default value is 0.05")
    }
    DF1 <- as.data.frame(subset(df, df[, 2] > 0 & df[, 2] !=
                                  "NA"))
    names(DF1) <- c("id", "ref", "pred")
    if (sortref == TRUE) {
      DF1 <- DF1[order(DF1$ref), ]
    }
    if (sortref == FALSE) {
      DF1 <- DF1
    }
    index <- as.numeric(row.names(DF1))
    id <- DF1$id
    ref <- DF1$ref
    pred <- DF1$pred
    n <- length(ref)
    min.ref <- min(ref)
    max.ref <- max(ref)
    min.pred <- min(pred)
    max.pred <- max(pred)
    if (n < 20)
      cat("WARNING: More than 20 samples are needed to run the Validation",
          "\n")
    cat("Validation Samples  =", n, "\n")
    if (n < 20)
      cat("WARNING: More than 20 samples are needed to run the Validation",
          "\n")
    ref.avg <- mean(ref)
    cat("Reference Mean  =", ref.avg, "\n")
    pred.avg <- mean(pred)
    cat("Predicted Mean  =", pred.avg, "\n")
    range.ref <- (max.ref) - (min.ref)
    range.pred <- (max.pred) - (min.pred)
    sd.ref <- sd(ref)
    sd.pred <- sd(pred)
    cov <- cov(pred, ref)
    var.ref <- var(ref)
    var.pred <- var(pred)
    res <- ref - pred
    par(mfrow = c(1, 1))
    l <- seq(1:n)
    {
      rmsep <- sqrt(sum((ref - pred)^2)/n)
      cat("RMSEP    :", rmsep, "\n")
    }
    {
      (bias <- mean(res))
      cat("Bias     :", bias, "\n")
    }
    {
      sep <- sd(res)
      cat("SEP      :", sep, "\n")
    }
    {
      r <- cor(ref, pred)
      cat("Corr     :", r, "\n")
    }
    {
      rsq <- (r^2)
      cat("RSQ      :", rsq, "\n")
    }
    {
      slope <- cov/var.pred
      cat("Slope    :", slope, "\n")
    }
    {
      intercept <- ref.avg - (slope * pred.avg)
      cat("Intercept:", intercept, "\n")
    }
    if (sd == FALSE) {
      cat("*** Std Dev of the model not supplied ***",
          sep = "", "\n")
      cat("***      RPD not calculated           ***",
          sep = "", "\n")
    }
    if (nc != FALSE) {
      RPD <- sd/sep
      cat("RPD                 :", RPD, "  ")
      if (RPD > 4.1)
        cat("Excellent", "\n")
      if ((RPD > 3.5) & (RPD < 4))
        cat("Very Good", "\n")
      if ((RPD > 2.9) & (RPD < 3.5))
        cat("Good", "\n")
      if ((RPD > 2.4) & (RPD < 2.9))
        cat("Fair", "\n")
      if ((RPD > 1.9) & (RPD < 2.4))
        cat("Poor", "\n")
      if (RPD < 1.9)
        cat("Very Poor", "\n")
    }
    Table1 <- data.frame(index, DF1, res)
    out_ualpos <- subset(Table1, res > (3 * sep))
    out_uwlpos <- subset(Table1, res > (2 * sep) & res <= (3 *
                                                             sep))
    into_wlpos <- subset(Table1, res > (sep) & res <= (2 * sep))
    into_lpos <- subset(Table1, res >= 0 & res <= (sep))
    into_lneg <- subset(Table1, res <= 0 & res >= (-sep))
    into_wlneg <- subset(Table1, res >= (-2 * sep) & res < (-sep))
    out_lwlneg <- subset(Table1, res < (-2 * sep) & res >= (-3 *
                                                              sep))
    out_lalneg <- subset(Table1, res < (-3 * sep))
    NL1 <- length(out_ualpos[, 4])
    NL2 <- length(out_uwlpos[, 4])
    NL3 <- length(into_wlpos[, 4])
    NL4 <- length(into_lpos[, 4])
    NL5 <- length(into_lneg[, 4])
    NL6 <- length(into_wlneg[, 4])
    NL2 <- length(out_lwlneg[, 4])
    NL1 <- length(out_lalneg[, 4])
    pred.corr1 <- round((bias + pred), 2)
    pred.corr2 <- round((intercept + (slope * pred)), 2)
    pred.corr <- round((intercept + (slope * pred)), 2)
    res.corr1 <- round((ref - pred.corr1), 2)
    res.corr2 <- round((ref - pred.corr2), 2)
    if ((nc == FALSE) & (p == FALSE) & (alpha == FALSE) & (sec ==
                                                           FALSE)) {
      cat("*** Details of the model used for prediction not supplied ***",
          sep = "", "\n")
      cat("***      SEP significance not calculated                  ***",
          sep = "", "\n")
    }
    {
      if ((nc != FALSE) & (p != FALSE) & (sec != FALSE)) {
        {
          v <- n - 1
          m <- nc - p - 1
          fvalue <- qf((1 - alpha), v, m)
          sqrtfvalue <- sqrt(fvalue)
          Tue <- sec * sqrtfvalue
          cat("UECLs    :", Tue, "\n")
        }
        if (sep < Tue) {
          cat("***SEP is bellow UECLs (O.K)***",
              sep = "", "\n")
        }
        else {
          cat("***SEP is over UECLs (Review)***",
              sep = "", "\n")
        }
      }
    }
    res.corr2.sq <- (res.corr2)^2
    sum.res2.sq <- (sum((res.corr2)^2))/(n - 2)
    Sres <- round((sqrt(sum.res2.sq)), 2)
    cat("Residual Std Dev is :", Sres, "\n")
    ttab.slp <- qt((1 - (alpha/2)), n)
    tobs.slp <- (abs(slope - 1)) * (sqrt((var.pred * (n - 1))/(Sres^2)))
    {
      if (tobs.slp >= ttab.slp)
        cat("    ***Slope/Intercept adjustment is recommended***",
            sep = "", "\n")
      else cat("    ***Slope/Intercept adjustment in not necessary***",
               sep = "", "\n")
    }
    {
      ttab <- qt((1 - (alpha/2)), n)
      BCL <- ((ttab * sep)/sqrt(n))
      BCLpc <- BCL * 100
      cat("Bias     :", bias, "\n")
      cat("SEP      :", sep, "\n")
      cat("BCL(+/-):", BCL, "\n")
      cat("BCL percentage:", BCLpc, "\n")
    }
    {
      if ((abs(bias) > BCL) & (tobs.slp < ttab.slp))
        cat("      ***Bias adjustment is recommended***",
            sep = "", "\n")
      else cat("***Bias adjustment in not necessary***",
               sep = "", "\n")
    }
    val_statistics <- list(N = n, Bias = bias, Slope = slope,
                           Intercept = intercept, RMSEP = rmsep, SEP = sep, Sres = Sres)
    res.corr <- round((ref - pred.corr), 2)
    Table2 <- data.frame(Table1, res.corr1, res.corr2)
    res68 <- subset(Table1, res <= sep & res >= (-sep))
    res68corr <- subset(Table2, res.corr <= sep & res.corr >=
                          (-sep))
    res68corr2 <- subset(Table2, res.corr2 <= Sres & res.corr2 >=
                           (-Sres))
    N1 <- length(res68[, 4])
    N1pc <- (N1 * 100)/n
    N1corr <- length(res68corr[, 5])
    N1corrpc <- (N1corr * 100)/n
    N1corr2 <- length(res68corr[, 6])
    N1corr2pc <- (N1corr2 * 100)/n
    cat("Without any adjustment and using  SEP as std dev the residual distibution is:",
        "\n")
    cat("  Residuals into 68%   prob (+/- 1SEP)    =",
        N1)
    cat("     % =", N1pc, "\n")
    res95 <- subset(Table1, res <= (2 * sep) & res >= (-2 * sep))
    res95corr <- subset(Table2, res.corr <= (2 * sep) & res.corr >=
                          (-2 * sep))
    res95corr2 <- subset(Table2, res.corr2 <= (2 * Sres) & res.corr2 >=
                           (-2 * Sres))
    N2 <- length(res95[, 4])
    N2pc <- (N2 * 100)/n
    N2corr <- length(res95corr[, 5])
    N2corrpc <- (N2corr * 100)/n
    N2corr2 <- length(res95corr2[, 6])
    N2corr2pc <- (N2corr2 * 100)/n
    cat("  Residuals into 95%   prob (+/- 2SEP)    =",
        N2)
    cat("     % =", N2pc, "\n")
    res99.5 <- subset(Table1, res <= (3 * sep) & res >= (-3 *
                                                           sep))
    res99.5corr <- subset(Table2, res.corr <= (3 * sep) & res.corr >=
                            (-3 * sep))
    res99.5corr2 <- subset(Table2, res.corr2 <= (3 * Sres) &
                             res.corr2 >= (-3 * Sres))
    N3 <- length(res99.5[, 4])
    N3pc <- (N3 * 100)/n
    N3corr <- length(res99.5corr[, 5])
    N3corrpc <- (N3corr * 100)/n
    N3corr2 <- length(res99.5corr2[, 6])
    N3corr2pc <- (N3corr2 * 100)/n
    cat("  Residuals into 99.5% prob (+/- 3SEP)    =",
        N3)
    cat("     % =", N3pc, "\n")
    res.out <- subset(Table1, res > (3 * sep) | res < (-3 * sep))
    res.outcorr <- subset(Table2, res.corr1 > (3 * sep) | res.corr1 <
                            (-3 * sep))
    res.outcorr2 <- subset(Table2, res.corr2 > (3 * Sres) | res.corr2 <
                             (-3 * Sres))
    N4 <- length(res.out[, 4])
    N4pc <- (N4 * 100)/n
    N4corr <- length(res.outcorr[, 5])
    N4corrpc <- (N4corr * 100)/n
    N4corr2 <- length(res.outcorr[, 6])
    N4corr2pc <- (N4corr2 * 100)/n
    cat("  Residuals outside 99.5% prob (+/- 3SEP) =",
        N4)
    cat("     % =", N4pc, "\n")
    EQSmin.ref <- min(ref)
    EQSmax.ref <- max(ref)
    EQSmean.ref <- mean(ref)
    EQSsd.ref <- sd(ref)
    EQSmin.pred <- min(pred)
    EQSmax.pred <- max(pred)
    EQSmean.pred <- mean(pred)
    EQSsd.pred <- sd(pred)
    EQSmin.pred.corr1 <- min(pred.corr1)
    EQSmax.pred.corr1 <- max(pred.corr1)
    EQSmean.pred.corr1 <- mean(pred.corr1)
    EQSsd.pred.corr1 <- sd(pred.corr1)
    EQSmin.pred.corr2 <- min(pred.corr2)
    EQSmax.pred.corr2 <- max(pred.corr2)
    EQSmean.pred.corr2 <- mean(pred.corr2)
    EQSsd.pred.corr2 <- sd(pred.corr2)
    EQS.range <- c(EQSmin.ref, EQSmin.pred, EQSmax.ref, EQSmax.pred,
                   EQSmin.pred.corr1, EQSmax.pred.corr1, EQSmin.pred.corr2,
                   EQSmax.pred.corr2)
    min.EQS <- min(EQS.range)
    max.EQS <- max(EQS.range)
    X1ref <- seq(EQSmin.ref, EQSmax.ref, by = 0.01)
    X1pred <- seq(EQSmin.pred, EQSmax.pred, by = 0.01)
    X1pred.corr1 <- seq(EQSmin.pred.corr1, EQSmax.pred.corr1,
                        by = 0.01)
    X1pred.corr2 <- seq(EQSmin.pred.corr2, EQSmax.pred.corr2,
                        by = 0.01)
    boxp_ref <- boxplot(ref, plot = FALSE)
    boxp_stats <- boxp_ref$stats
    boxp_stats_min <- boxp_ref$stats[1, 1]
    boxp_stats_q1 <- boxp_ref$stats[2, 1]
    boxp_stats_median <- boxp_ref$stats[3, 1]
    boxp_stats_q3 <- boxp_ref$stats[4, 1]
    boxp_stats_max <- boxp_ref$stats[5, 1]
    bpref_out <- length(boxp_ref$out)
    #### BOX PLOTS
    ## Non corrected
    if ((abs(bias) < BCL) & (tobs.slp < ttab.slp)) {
      layout(matrix(c(1,1,2,3), 2, 2, byrow = TRUE))
      boxplot(ref, pred, main = "Boxplot Comparison",
              names = c("REF", "PRED"), medcol = "blue",
              boxfill = c("salmon", "cyan"),
              cex = 1, horizontal = T)
      edaplot(ref, H.freq = TRUE,P.main= "Distribution of Reference values",
              B.col = "salmon", S.col = "salmon", S.cex = 3, H.col = "salmon")
      edaplot(pred, H.freq = TRUE,P.main= "Distribution of Predicted values",
              B.col = "cyan", S.col = "cyan", S.cex = 3, H.col = "cyan")

    }

    ## Bias corrected
    if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp)) {
      layout(matrix(c(1,1,1,2,3,4), 2, 3, byrow = TRUE))
      boxplot(ref, pred.corr1, pred, main = "Boxplot Comparison",
              medcol = c("blue", "red", "white"),
              outcol = "red", outbg = "red",
              boxfill = c("salmon", "green", "cyan"),
              names = c("REF", "PRED(C)", "PRED"),
              cex = 1, horizontal = T)
      mtext("***Bias adjustment recommended***", side = 3,
            col = "red", cex = 0.7)
      edaplot(ref, H.freq = TRUE,P.main= "Distribution of Reference values",
              B.col = "salmon", S.col = "salmon", S.cex = 3, H.col = "salmon")
      edaplot(pred.corr1, H.freq = TRUE,P.main= "Dist. Pred. values bias corrected",
              B.col = "green", S.col = "green", S.cex = 3, H.col = "green")
      edaplot(pred, H.freq = TRUE,P.main= "Distribution of Predicted values",
              B.col = "cyan", S.col = "cyan", S.cex = 3, H.col = "cyan")
    }

    ## Slope/Intercept corrected
    if (tobs.slp > ttab.slp) {
      boxplot(ref, pred.corr2, pred, main = "Boxplot Comparison",
              medcol = c("blue", "blue", "red",
                         "white"), outcol = "red", outbg = "red",
              boxfill = c("salmon", "orange", "royalblue"),
              names = c("REF", "PRED(S/I)", "PRED"),
              cex = 1, horizontal = T)
      mtext("***Slope/Intercept adjustment recommended***",
            side = 3, col = "red", cex = 0.7)
      edaplot(ref, H.freq = TRUE,P.main= "Distribution of Reference values",
              B.col = "salmon", S.col = "salmon", S.cex = 3, H.col = "salmon")
      edaplot(pred.corr2, H.freq = TRUE,P.main= "Dist. Pred. values S/I corrected",
              B.col = "orange", S.col = "orange", S.cex = 3, H.col = "orange")
      edaplot(pred, H.freq = TRUE,P.main= "Distribution of Predicted values",
              B.col = "cyan", S.col = "cyan", S.cex = 3, H.col = "cyan")
    }

    Table2_Q1toMIN <- Table2[which(Table2$ref >= boxp_stats_min &
                                     Table2$ref <= boxp_stats_q1), ]
    Q1toMIN <- rep("Q1 to MIN ", nrow(Table2_Q1toMIN))
    ColQ1toMIN <- rep("#0000FF", nrow(Table2_Q1toMIN))
    Table2_Q1toMIN <- data.frame(Table2_Q1toMIN, Q1toMIN, as.character(ColQ1toMIN))
    colnames(Table2_Q1toMIN) <- c("index", "id",
                                  "ref", "pred", "res", "res.corr1",
                                  "res.corr2", "Q", "Color")
    Table2_Q1 <- Table2[which(Table2$ref > boxp_stats_q1 & Table2$ref <=
                                boxp_stats_median), ]
    Q1 <- rep("Q1", nrow(Table2_Q1))
    ColQ1 <- rep("#00CC66", nrow(Table2_Q1))
    Table2_Q1 <- data.frame(Table2_Q1, Q1, ColQ1)
    colnames(Table2_Q1) <- c("index", "id", "ref",
                             "pred", "res", "res.corr1", "res.corr2",
                             "Q", "Color")
    Table2_Q2 <- Table2[which(Table2$ref > boxp_stats_median &
                                Table2$ref <= boxp_stats_q3), ]
    Q2 <- rep("Q2", nrow(Table2_Q2))
    ColQ2 <- rep("#FFFF33", nrow(Table2_Q2))
    Table2_Q2 <- data.frame(Table2_Q2, Q2, ColQ2)
    colnames(Table2_Q2) <- c("index", "id", "ref",
                             "pred", "res", "res.corr1", "res.corr2",
                             "Q", "Color")
    Table2_Q2toMAX <- Table2[which(Table2$ref > boxp_stats_q3 &
                                     Table2$ref <= boxp_stats_max), ]
    Q2toMAX <- rep("Q2 to MAX", nrow(Table2_Q2toMAX))
    ColQ2toMAX <- rep("#FF9933", nrow(Table2_Q2toMAX))
    Table2_Q2toMAX <- data.frame(Table2_Q2toMAX, Q2toMAX, ColQ2toMAX)
    colnames(Table2_Q2toMAX) <- c("index", "id",
                                  "ref", "pred", "res", "res.corr1",
                                  "res.corr2", "Q", "Color")
    Table2_BPREFOUT <- Table2[which(Table2$ref < boxp_stats_min |
                                      Table2$ref > boxp_stats_max), ]
    BPREFOUT <- rep("BPOUT", nrow(Table2_BPREFOUT))
    ColBPREFOUT <- rep("#FF0000", nrow(Table2_BPREFOUT))
    Table2_BPREFOUT <- data.frame(Table2_BPREFOUT, BPREFOUT,
                                  ColBPREFOUT)
    colnames(Table2_BPREFOUT) <- c("index", "id",
                                   "ref", "pred", "res", "res.corr1",
                                   "res.corr2", "Q", "Color")
    Table3 <- rbind(Table2_Q1toMIN, Table2_Q1, Table2_Q2, Table2_Q2toMAX,
                    Table2_BPREFOUT)
    Table3 <- Table3[order(index), ]
    resintolimits <- subset(Table3, res < (2 * sep) & res > (-2 *
                                                               sep))
    resintolimits_2 <- resintolimits[, c(1:3)]
    reswarning <- subset(Table3, res >= (2 * sep) & res <= (3 *
                                                              sep) | res <= (-2 * sep) & res >= (-3 * sep))
    reswarninglist <- reswarning[, 1]
    reswarning_out <- (nrow(reswarning)/nrow(DF1)) * 20
    resaction <- subset(Table3, res > (3 * sep) | res < (-3 *
                                                           sep))
    resactionlist <- resaction[, 1]
    resaction_out <- (nrow(resaction)/nrow(DF1)) * 1000
    xystat <- vector("expression", 8)
    xystat[1] <- substitute(expression(N................ == MYNVALUE),
                            list(MYNVALUE = format(n, dig = 3)))[2]
    xystat[2] <- substitute(expression(RSQ.......... == MYRSQVALUE),
                            list(MYRSQVALUE = format(rsq, dig = 3)))[2]
    xystat[3] <- substitute(expression(Slope........ == MYSLPVALUE),
                            list(MYSLPVALUE = format(slope, digits = 3)))[2]
    xystat[4] <- substitute(expression(Intercept... == MYINTVALUE),
                            list(MYINTVALUE = format(intercept, digits = 3)))[2]
    xystat[5] <- substitute(expression(RMSEP.... == MYRMSEPVALUE),
                            list(MYRMSEPVALUE = format(rmsep, digits = 3)))[2]
    xystat[6] <- substitute(expression(Bias.......... == MYBIASVALUE),
                            list(MYBIASVALUE = format(bias, digits = 3)))[2]
    xystat[7] <- substitute(expression(SEP.......... == MYSEPVALUE),
                            list(MYSEPVALUE = format(sep, digits = 3)))[2]
    xystat[8] <- substitute(expression(Sres.......... == MYSresVALUE),
                            list(MYSresVALUE = format(Sres, digits = 3)))[2]
    {
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("With Bias correction and using SEP as standard deviation, the Residual Distribution would be:",
            sep = "", "\n")
    }
    {
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("  Residuals into 68%   prob (+/- 1SEP)     =",
            N1corr)
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("     % =", N1corrpc, "\n")
    }
    {
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("  Residuals into 95%   prob (+/- 2SEP)     =",
            N2corr)
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("     % =", N2corrpc, "\n")
    }
    {
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("  Residuals into 99.5% prob (+/- 3SEP)     =",
            N3corr)
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("    % =", N3corrpc, "\n")
    }
    {
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("  Residuals outside  99.5% prob (> 3SEP)   =",
            N4corr)
      if ((abs(bias) >= BCL) & (tobs.slp < ttab.slp))
        cat("     % =", N4corrpc, "\n")
    }
    {
      if (tobs.slp > ttab.slp)
        cat("With S/I correction and using Sres as standard deviation, the Residual Distribution would be:",
            sep = "", "\n")
    }
    if (tobs.slp > ttab.slp) {
      cat("  Residuals into 68%   prob (+/- 1Sres)     =",
          N1corr2)
    }
    if (tobs.slp > ttab.slp) {
      cat("     % =", N1corr2pc, "\n")
    }
    if (tobs.slp > ttab.slp) {
      cat("  Residuals into 95%   prob (+/- 2Sres)     =",
          N2corr2)
    }
    if (tobs.slp > ttab.slp) {
      cat("     % =", N2corr2pc, "\n")
    }
    if (tobs.slp > ttab.slp) {
      cat("  Residuals into 99.5% prob (+/- 3Sres)     =",
          N3corr2)
    }
    if (tobs.slp > ttab.slp) {
      cat("    % =", N3corr2pc, "\n")
    }
    if (tobs.slp > ttab.slp) {
      cat("  Residuals outside  99.5% prob (> 3Sres)   =",
          N4corr2)
    }
    if (tobs.slp > ttab.slp) {
      cat("     % =", N4corr2pc, "\n")
    }
    list(val_statistics = val_statistics, Table2_Q1 = Table2_Q1toMIN,
         Table2_Q2 = Table2_Q1, Table2_Q3 = Table2_Q2, Table2_Q4 = Table2_Q2toMAX,
         Table2_BPREFOUT = Table2_BPREFOUT, Table3 = Table3, Boxplot_Outliers = bpref_out,
         ResIntoLimits = resintolimits_2, ResWarning = reswarning,
         ResWarningList = reswarninglist, ResWarningOut = reswarning_out,
         ResAction = resaction, ResActionList = resactionlist,
         ResActionOut = resaction_out)
  }
