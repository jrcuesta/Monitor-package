monitor_histplot<-
  function(df,sortref=TRUE,nc=FALSE,p=FALSE,alpha=0.05,
           sec=FALSE,sd=FALSE){
    if(ncol(df) > 3){
      stop("Dataframe columns must be four: Sample ID, Ref Value and Pred Value")
    }
    if(alpha > 0.1 | alpha == FALSE){
      stop("the alpha value must be between 0,1 and 0.001
           - Default value is 0.05")
    }
    DF1<-as.data.frame(subset(df,df[,2] > 0
                              & df[,2] !="NA"))
    names(DF1)<-c("id","ref","pred")
    if(sortref==TRUE){
      DF1<-DF1[order(DF1$ref), ]
    }
    if(sortref==FALSE){
      DF1<-DF1
    }
    index<-as.numeric(row.names(DF1))
    id<-DF1$id
    ref<-DF1$ref
    pred<-DF1$pred
    n<-length(ref)
    min.ref<-min(ref)
    max.ref<-max(ref)
    min.pred<-min(pred)
    max.pred<-max(pred)
    if(n<20) cat("WARNING: More than 20 samples are needed to run the Validation","\n")
    print("BASIC STATISTICS")
    cat("Validation Samples  =",n,"\n")
    if(n<20) cat("WARNING: More than 20 samples are needed to run the Validation","\n")
    ref.avg<-mean(ref)
    cat("Reference Mean  =",ref.avg,"\n")
    pred.avg<-mean(pred)
    cat("Predicted Mean  =",pred.avg,"\n")
    range.ref<-(max.ref)-(min.ref)
    range.pred<-(max.pred)-(min.pred)
    sd.ref<-sd(ref)
    sd.pred<-sd(pred)
    cov<-cov(pred,ref)
    var.ref<-var(ref)
    var.pred<-var(pred)
    res<-ref-pred
    ####  PLOT DISTRIBUTION  #######
    par(mfrow=c(1,1))
    l<-seq(1:n)
    {rmsep<-sqrt(sum((ref-pred)^2)/n)
      cat("RMSEP    :",rmsep,"\n")}
    {(bias<-mean(res))
      cat("Bias     :",bias,"\n")}
    {sep<-sd(res)
      cat("SEP      :",sep,"\n")}
    {r<-cor(ref,pred)
      cat("Corr     :",r,"\n")}
    {rsq<-(r^2)
      cat("RSQ      :",rsq,"\n")}
    {slope<-cov/var.pred
      cat("Slope    :",slope,"\n")}
    {intercept<-ref.avg-(slope*pred.avg)
      cat("Intercept:",intercept,"\n")}
    #{RER<-range.pred/sep        # RER="Range Error Ratio"
    #cat("RER                 :",RER,"  ")
    #if(RER>41) cat("Excellent","\n")
    #if((RER>31)&(RER<41))cat("Very Good","\n")
    #if((RER>21)&(RER<31)) cat("Good","\n")
    #if((RER>13)&(RER<21)) cat("Fair","\n")
    #if((RER>7)&(RER<13)) cat("Poor","\n")
    #if(RER<7) cat("Very Poor","\n")
    #}
    ########### RPD CALCULATION ##############################
    if(sd == FALSE){
      cat("*** Std Dev of the model not supplied ***",sep="","\n")
      cat("***      RPD not calculated           ***",sep="","\n")}
    if(nc != FALSE){
      RPD<-sd/sep        # RPD="Ratio SEP to SD"
      cat("RPD                 :",RPD,"  ")
      if(RPD>4.1) cat("Excellent","\n")
      if((RPD>3.5)&(RPD<4.0))cat("Very Good","\n")
      if((RPD>2.9)&(RPD<3.5)) cat("Good","\n")
      if((RPD>2.4)&(RPD<2.9)) cat("Fair","\n")
      if((RPD>1.9)&(RPD<2.4)) cat("Poor","\n")
      if(RPD<1.9) cat("Very Poor","\n")
    }
    #Table1<-as.data.frame((cbind(id,ref,pred,res)),as.is=TRUE)
    ####Table 1####
    Table1<-data.frame(index,DF1,res)
    out_ualpos<-subset(Table1,res>(3*sep))
    out_uwlpos<-subset(Table1,res>(2*sep)& res<=(3*sep))
    into_wlpos<-subset(Table1,res>(sep) & res<=(2*sep))
    into_lpos<-subset(Table1,res>=0 & res<=(sep))
    into_lneg<-subset(Table1,res<=0 & res>=(-sep))
    into_wlneg<-subset(Table1,res>=(-2*sep) & res<(-sep))
    out_lwlneg<-subset(Table1,res<(-2*sep) & res>=(-3*sep))
    out_lalneg<-subset(Table1,res<(-3*sep))
    NL1<-length(out_ualpos[,4])
    NL2<-length(out_uwlpos[,4])
    NL3<-length(into_wlpos[,4])
    NL4<-length(into_lpos[,4])
    NL5<-length(into_lneg[,4])
    NL6<-length(into_wlneg[,4])
    NL2<-length(out_lwlneg[,4])
    NL1<-length(out_lalneg[,4])
    pred.corr1<-round((bias+pred),2)
    pred.corr2<-round((intercept+(slope*pred)),2)
    pred.corr<-round((intercept+(slope*pred)),2)
    res.corr1<-round((ref-pred.corr1),2)
    res.corr2<-round((ref-pred.corr2),2)
    ##################  SEP SIGNIFICANCE   #############################################################
    print("SEP SIGNIFICANCE CALCULATION")
    if((nc == FALSE)&(p == FALSE)&(alpha == FALSE)&(sec == FALSE)){
      cat("*** Details of the model used for prediction not supplied ***",sep="","\n")
      cat("***      SEP significance not calculated                  ***",sep="","\n")}
    {if((nc != FALSE)&(p!= FALSE)&(sec!= FALSE)){
      {v<-n-1
      m<-nc-p-1
      fvalue<-qf((1-alpha),v,m)
      sqrtfvalue<-sqrt(fvalue)
      Tue<-sec*sqrtfvalue
      cat("UECLs    :",Tue,"\n")}
      if(sep<Tue){cat("***SEP is bellow UECLs (O.K)***",sep="","\n")}
      else
      {cat("***SEP is over UECLs (Review)***",sep="","\n")}}}
    ##################  S / I SIGNIFICANCE #############################################################
    res.corr2.sq<-(res.corr2)^2                                 #square of the S/I corrected residuals
    sum.res2.sq<-(sum((res.corr2)^2))/(n-2)                     #ISO 12099:2010  page 10 (14)
    Sres<-round((sqrt(sum.res2.sq)),2)
    #Sres=Residual Standard Deviation is like the SEP when the predicted values
    #are corrected for slope and intercept)
    print("SLOPE / INTERCEPT SIGNIFICANCE CALCULATION")
    cat("Residual Std Dev is :",Sres,"\n")
    ttab.slp<-qt((1 - (alpha/2)),n)                             #t distribution alpha=0,05 prob=5% Type I error
    tobs.slp<-(abs(slope-1))*(sqrt((var.pred*(n-1))/(Sres^2)))  #ISO 12099:2010  page 10 (13)
    {if (tobs.slp>=ttab.slp) cat("    ***Slope/Intercept adjustment is recommended***",sep="","\n")
      else
        cat("    ***Slope/Intercept adjustment in not necessary***",sep="","\n")}
    ##########BIAS  SIGNIFICANCE###########################
    print("BIAS SIGNIFICANCE CALCULATION")
    {ttab<-qt((1 - (alpha/2)),n)                                #t distribution alpha=0,05 prob=5% Type I error
    BCL<-((ttab*sep)/sqrt(n))                                   # Bias Confidence Limits
    BCLpc<-BCL*100                                              # Bias Confidence Limits %
    cat("Bias     :",bias,"\n")                                 # Bias print
    cat("SEP      :",sep,"\n")                                  # SEP print
    cat("BCL(+/-):",BCL,"\n")                                   # BCL print
    cat("BCL percentage:",BCLpc,"\n")                           # BCL % print
    }
    {if ((abs(bias)>BCL)&(tobs.slp<ttab.slp)) cat("      ***Bias adjustment is recommended***",sep="","\n")
      else
        cat("***Bias adjustment in not necessary***",sep="","\n")}
    ################## VALIDATION STATISTICS ####################################
    val_statistics<-list(N=n,Bias=bias,Slope=slope,
                                Intercept=intercept,RMSEP=rmsep,SEP=sep,Sres=Sres)
    ####Table 2####
    res.corr<-round((ref-pred.corr),2)
    #Table2<-as.data.frame((cbind(id,ref,pred,res,res.corr1,res.corr2)),as.is=TRUE)
    Table2<-data.frame(Table1,res.corr1,res.corr2)
    res68<-subset(Table1,res<=sep & res>=(-sep) )                    #Into limits without adjustments
    res68corr<-subset(Table2,res.corr<=sep & res.corr>=(-sep))       #Into limits once Bias is adjusted
    res68corr2<-subset(Table2,res.corr2<=Sres & res.corr2>=(-Sres))  #Into limits once S/I is adjusted
    N1<-length(res68[,4])
    N1pc<-(N1*100)/n
    N1corr<-length(res68corr[,5])
    N1corrpc<-(N1corr*100)/n
    N1corr2<-length(res68corr[,6])
    N1corr2pc<-(N1corr2*100)/n
    print("RESIDUALS DISTRIUTION")
    cat("Without any adjustment and using  SEP as std dev the residual distibution is:","\n")
    cat("  Residuals into 68%   prob (+/- 1SEP)    =",N1)
    cat("     % =",N1pc,"\n")
    res95<-subset(Table1,res<=(2*sep) & res>=(-2*sep) )
    res95corr<-subset(Table2,res.corr<=(2*sep) & res.corr>=(-2*sep) )
    res95corr2<-subset(Table2,res.corr2<=(2*Sres) & res.corr2>=(-2*Sres) )
    N2<-length(res95[,4])
    N2pc<-(N2*100)/n
    N2corr<-length(res95corr[,5])
    N2corrpc<-(N2corr*100)/n
    N2corr2<-length(res95corr2[,6])
    N2corr2pc<-(N2corr2*100)/n
    cat("  Residuals into 95%   prob (+/- 2SEP)    =",N2)
    cat("     % =",N2pc,"\n")
    res99.5<-subset(Table1,res<=(3*sep) & res>=(-3*sep) )
    res99.5corr<-subset(Table2,res.corr<=(3*sep) & res.corr>=(-3*sep) )
    res99.5corr2<-subset(Table2,res.corr2<=(3*Sres) & res.corr2>=(-3*Sres) )
    N3<-length(res99.5[,4])
    N3pc<-(N3*100)/n
    N3corr<-length(res99.5corr[,5])
    N3corrpc<-(N3corr*100)/n
    N3corr2<-length(res99.5corr2[,6])
    N3corr2pc<-(N3corr2*100)/n
    cat("  Residuals into 99.5% prob (+/- 3SEP)    =",N3)
    cat("     % =",N3pc,"\n")
    res.out<-subset(Table1,res>(3*sep)| res<(-3*sep))
    res.outcorr<-subset(Table2,res.corr1>(3*sep) | res.corr1<(-3*sep))
    res.outcorr2<-subset(Table2,res.corr2>(3*Sres) | res.corr2<(-3*Sres))
    N4<-length(res.out[,4])
    N4pc<-(N4*100)/n
    N4corr<-length(res.outcorr[,5])
    N4corrpc<-(N4corr*100)/n
    N4corr2<-length(res.outcorr[,6])
    N4corr2pc<-(N4corr2*100)/n
    cat("  Residuals outside 99.5% prob (+/- 3SEP) =",N4)
    cat("     % =",N4pc,"\n")
    #cat("  Samples outside UAL  =",NL1,"\n")
    #cat("  Samples outside UWL  =",NL2,"\n")
    #cat("  Samples inside   WL  =",NL23,"\n")
    #cat("  Samples outside LWL  =",NL3,"\n")
    #cat("  Samples outside LAL  =",NL4,"\n")
    ##################  RESIDUALS HISTOGRAM #####################################
    EQSmin.ref<-min(ref)
    EQSmax.ref<-max(ref)
    EQSmean.ref<-mean(ref)
    EQSsd.ref<-sd(ref)
    EQSmin.pred<-min(pred)
    EQSmax.pred<-max(pred)
    EQSmean.pred<-mean(pred)
    EQSsd.pred<-sd(pred)
    EQSmin.pred.corr1<-min(pred.corr1)
    EQSmax.pred.corr1<-max(pred.corr1)
    EQSmean.pred.corr1<-mean(pred.corr1)
    EQSsd.pred.corr1<-sd(pred.corr1)
    EQSmin.pred.corr2<-min(pred.corr2)
    EQSmax.pred.corr2<-max(pred.corr2)
    EQSmean.pred.corr2<-mean(pred.corr2)
    EQSsd.pred.corr2<-sd(pred.corr2)
    EQS.range<-c(EQSmin.ref,EQSmin.pred,EQSmax.ref,EQSmax.pred,
                 EQSmin.pred.corr1,EQSmax.pred.corr1,
                 EQSmin.pred.corr2,EQSmax.pred.corr2)
    min.EQS<-min(EQS.range)
    max.EQS<-max(EQS.range)
    X1ref<-seq(EQSmin.ref,EQSmax.ref,by=0.01)
    X1pred<-seq(EQSmin.pred,EQSmax.pred,by=0.01)
    X1pred.corr1<-seq(EQSmin.pred.corr1,EQSmax.pred.corr1,by=0.01)
    X1pred.corr2<-seq(EQSmin.pred.corr2,EQSmax.pred.corr2,by=0.01)
    #lines(density(ref),col="brown",lwd=2)
    #lines(X1ref,dnorm(X1ref,EQSmean.ref,EQSsd.ref),col="red",lwd=2)
    hist(ref,freq=FALSE,breaks=(n/3),col=rgb(1,0,0,0.5),
         xlim=c(min.EQS-0.1*min.ref,max.EQS+0.3*max.ref),
         main="Ref vs. Pred Histogram")
    lines(X1ref,dnorm(X1ref,EQSmean.ref,EQSsd.ref),col="blue",lty=2,lwd=3)
    abline(v=EQSmean.ref,col="blue",lty=2,lwd=3)
    #### Histograms without correction #######
    if((abs(bias)<BCL)&(tobs.slp<ttab.slp)){
      hist(pred,freq=FALSE,breaks=(n/3),col=rgb(0,0,1,0.5),
           xlim=c(min.EQS-0.1*min.ref,max.EQS+0.3*max.ref),
           main="",add=T)
      #lines(density(ref),col="blue",lty=2,lwd=3)
      abline(v=EQSmean.pred,col="red",lty=2,lwd=3)
      #lines(density(pred),col="red",lty=2,lwd=3)
      lines(X1pred,dnorm(X1pred,EQSmean.pred,EQSsd.pred),col="red",lty=2,lwd=3)
      mtext("Look for gaps in the Histogram due to different populations",
            side=1,col="red",cex=0.7)
      legend("topright", c("Reference","Predicted","Overlaped","Ref Dens","Pred Dens"), cex=1,
             col=c("salmon","royalblue","purple3","blue","red"),
             pch=c(22,22,22,NA,NA),
             lty=c(NA,NA,NA,2,2),
             lwd=c(4,4,4,2,2),bty="n",y.intersp = 0.6  )
    }
    ####Histograms Bias corrected####
    if((abs(bias)>=BCL)&(tobs.slp<ttab.slp)){
      hist(pred.corr1,freq=FALSE,breaks=(n/3),col=rgb(0,0,1,0.5),
           xlim=c(min.EQS-0.1*min.ref,max.EQS+0.3*max.ref),
           main="",
           add=T)
      #lines(density(pred.corr1),col="green",lty=2,lwd=3)
      abline(v=EQSmean.pred,col="red",lty=2,lwd=3)
      lines(X1pred,dnorm(X1pred,EQSmean.pred,EQSsd.pred),col="red",lty=2,lwd=3)
      lines(X1pred.corr1,dnorm(X1pred.corr1,EQSmean.pred.corr1,EQSsd.pred.corr1),
            col="green",lty=2,lwd=3)
      mtext("***Bias adjustment recommended***",side=3,col="red",cex=0.7)
      legend("topright", c("Reference","Pred Bias corr","Overlaped","Ref Dens",
                           "Pred Dens","Bias Corr Dens"), cex=1,
             col=c("salmon","royalblue","purple3","blue","red","green"),
             pch=c(22,22,22,NA,NA,NA),
             lty=c(NA,NA,NA,2,2,2),
             lwd=c(4,4,4,2,2,2),bty="n",y.intersp = 0.6  )
    }
    ####S/I corrected####
    if(tobs.slp>ttab.slp){
      hist(pred.corr1,freq=FALSE,breaks=(n/3),col=rgb(0,0,1,0.5),
           xlim=c(min.EQS-0.1*min.ref,max.EQS+0.3*max.ref),
           main="",
           add=T)
      #lines(density(pred.corr2),col="green",lty=2,lwd=3)
      lines(X1pred,dnorm(X1pred,EQSmean.pred,EQSsd.pred),col="red",lty=2,lwd=3)
      lines(X1pred.corr2,dnorm(X1pred.corr2,EQSmean.pred.corr2,EQSsd.pred.corr2),
            col="green",lty=2,lwd=3)
      mtext("***Slope/Intercept adjustment recommended***",
            side=3,col="red",cex=0.7)
      legend("topright", c("Reference","Pred S/I corr","Overlaped","Ref Dens",
                           "Pred Dens","S/I Corr Dens"), cex=1,
             col=c("salmon","royalblue","purple3","blue","red","green"),
             pch=c(22,22,22,NA,NA,NA),
             lty=c(NA,NA,NA,2,2,2),
             lwd=c(4,4,4,2,2,2),bty="n",y.intersp = 0.6  )
    }
    ###################   BOX PLOT ####################################################
    ####non corrected####
    boxp_ref<-boxplot(ref,plot = FALSE)
    boxp_stats<-boxp_ref$stats                  #matriz estadística del boxplot
    boxp_stats_min<-boxp_ref$stats[1,1]         #valor mínimo  Q3-(1.5*IQR)
    boxp_stats_q1<-boxp_ref$stats[2,1]          #linea primer cuartil
    boxp_stats_median<-boxp_ref$stats[3,1]      #linea de la mediana
    boxp_stats_q3<-boxp_ref$stats[4,1]          #linea tercer cuartil
    boxp_stats_max<-boxp_ref$stats[5,1]         #valor máximo  Q3+(1.5*IQR)
    bpref_out<-length(boxp_ref$out)          #muestras fuera de rango (min-max)

    #De la Tabla2 de muestras
    # las muestras entre el minimo Y el primer cuartil y llamarlas Q1
    Table2_Q1toMIN<-Table2[which(Table2$ref >= boxp_stats_min & Table2$ref <= boxp_stats_q1),]
    Q1toMIN<-rep("Q1 to MIN ",nrow(Table2_Q1toMIN))
    ColQ1toMIN<-rep("#0000FF",nrow(Table2_Q1toMIN))
    Table2_Q1toMIN<-data.frame(Table2_Q1toMIN,Q1toMIN,as.character(ColQ1toMIN))
    colnames(Table2_Q1toMIN)<-c("index","id","ref","pred","res","res.corr1","res.corr2","Q","Color")
    # las muestras entre  Q1 y la mediana y llamarlas Q2
    Table2_Q1<-Table2[which(Table2$ref > boxp_stats_q1 & Table2$ref <= boxp_stats_median),]
    Q1<-rep("Q1",nrow(Table2_Q1))
    ColQ1<-rep("#00CC66",nrow(Table2_Q1))
    Table2_Q1<-data.frame(Table2_Q1,Q1,ColQ1)
    colnames(Table2_Q1)<-c("index","id","ref","pred","res","res.corr1","res.corr2","Q","Color")

    # las muestras entre la mediana y Q3 y llamarlas Q3
    Table2_Q2<-Table2[which(Table2$ref > boxp_stats_median & Table2$ref <= boxp_stats_q3),]
    Q2<-rep("Q2",nrow(Table2_Q2))
    ColQ2<-rep("#FFFF33",nrow(Table2_Q2))
    Table2_Q2<-data.frame(Table2_Q2,Q2,ColQ2)
    colnames(Table2_Q2)<-c("index","id","ref","pred","res","res.corr1","res.corr2","Q","Color")
    # las muestras entre Q3 y el máximo y llamarlas Q4
    Table2_Q2toMAX<-Table2[which(Table2$ref > boxp_stats_q3 & Table2$ref <= boxp_stats_max),]
    Q2toMAX<-rep("Q2 to MAX",nrow(Table2_Q2toMAX))
    ColQ2toMAX<-rep("#FF9933",nrow(Table2_Q2toMAX))
    Table2_Q2toMAX<-data.frame(Table2_Q2toMAX,Q2toMAX,ColQ2toMAX)
    colnames(Table2_Q2toMAX)<-c("index","id","ref","pred","res","res.corr1","res.corr2","Q","Color")
    # las muestras fuera de rango total y llamarlas BPREFOUT
    Table2_BPREFOUT<-Table2[which(Table2$ref < boxp_stats_min | Table2$ref > boxp_stats_max),]
    BPREFOUT<-rep("BPOUT",nrow(Table2_BPREFOUT))
    ColBPREFOUT<-rep("#FF0000",nrow(Table2_BPREFOUT))
    Table2_BPREFOUT<-data.frame(Table2_BPREFOUT,BPREFOUT,ColBPREFOUT)
    colnames(Table2_BPREFOUT)<-c("index","id","ref","pred","res","res.corr1","res.corr2","Q","Color")
    #######  TABLE 3  ############
    Table3<-rbind(Table2_Q1toMIN,Table2_Q1,Table2_Q2,Table2_Q2toMAX,Table2_BPREFOUT)
    Table3<-Table3[order(index),]
    #############TABLES (Residuals)###########
    resintolimits<-subset(Table3,res<(2*sep)& res>(-2*sep))   #new
    resintolimits_2<-resintolimits[,c(1:3)]
    reswarning<-subset(Table3,res>=(2*sep) & res<=(3*sep)|res<=(-2*sep) & res>=(-3*sep) )
    reswarninglist<-reswarning[,1]
    reswarning_out<-(nrow(reswarning)/nrow(DF1))*20
    resaction<-subset(Table3,res>(3*sep)|res<(-3*sep))
    resactionlist<-resaction[,1]
    resaction_out<-(nrow(resaction)/nrow(DF1))*1000
    ##################  Statistics Labels for X-Y Plots) #######################################
    xystat<-vector("expression",8)
    xystat[1]<-substitute(expression(N................==MYNVALUE),
                          list(MYNVALUE= format(n,dig=3)))[2]
    xystat[2]<-substitute(expression(RSQ..........==MYRSQVALUE),
                          list(MYRSQVALUE= format(rsq,dig=3)))[2]
    xystat[3]<-substitute(expression(Slope........== MYSLPVALUE),
                          list(MYSLPVALUE = format(slope, digits = 3)))[2]
    xystat[4]<-substitute(expression(Intercept...== MYINTVALUE),
                          list(MYINTVALUE = format(intercept, digits = 3)))[2]
    xystat[5]<-substitute(expression(RMSEP....== MYRMSEPVALUE),
                          list(MYRMSEPVALUE = format(rmsep, digits = 3)))[2]
    xystat[6]<-substitute(expression(Bias..........== MYBIASVALUE),
                          list(MYBIASVALUE = format(bias, digits = 3)))[2]
    xystat[7]<-substitute(expression(SEP..........== MYSEPVALUE),
                          list(MYSEPVALUE = format(sep, digits = 3)))[2]
    xystat[8]<-substitute(expression(Sres..........== MYSresVALUE),
                          list(MYSresVALUE = format(Sres,digits = 3)))[2]
    #######################RESIDUALS PLOT################################################
    #### Bias corrected ####
    {if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))
      cat("With Bias correction and using SEP as standard deviation, the Residual Distribution would be:",
          sep="","\n")}
    {if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("  Residuals into 68%   prob (+/- 1SEP)     =",N1corr)
      if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("     % =",N1corrpc,"\n")}
    {if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("  Residuals into 95%   prob (+/- 2SEP)     =",N2corr)
      if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("     % =",N2corrpc,"\n")}
    {if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("  Residuals into 99.5% prob (+/- 3SEP)     =",N3corr)
      if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("    % =",N3corrpc,"\n")}
    {if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("  Residuals outside  99.5% prob (> 3SEP)   =",N4corr)
      if ((abs(bias)>=BCL)&(tobs.slp<ttab.slp))cat("     % =",N4corrpc,"\n")}
    #### S/I corrected ####
    {if (tobs.slp>ttab.slp)
      cat("With S/I correction and using Sres as standard deviation, the Residual Distribution would be:",
          sep="","\n")}
    if (tobs.slp>ttab.slp){cat("  Residuals into 68%   prob (+/- 1Sres)     =",N1corr2)}
    if (tobs.slp>ttab.slp){cat("     % =",N1corr2pc,"\n")}
    if (tobs.slp>ttab.slp){cat("  Residuals into 95%   prob (+/- 2Sres)     =",N2corr2)}
    if (tobs.slp>ttab.slp){cat("     % =",N2corr2pc,"\n")}
    if (tobs.slp>ttab.slp){cat("  Residuals into 99.5% prob (+/- 3Sres)     =",N3corr2)}
    if (tobs.slp>ttab.slp){cat("    % =",N3corr2pc,"\n")}
    if (tobs.slp>ttab.slp){cat("  Residuals outside  99.5% prob (> 3Sres)   =",N4corr2)}
    if (tobs.slp>ttab.slp){cat("     % =",N4corr2pc,"\n")}

    ###########################   TABLES   #####################################################################
    list(val_statistics=val_statistics)
  }
